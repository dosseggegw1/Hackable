# Structure de /pcap

```shell
# [tcpdump] Capture réseau passant par l'interface usb0
tcpdump.pcap

# [tcpdump] Capture réseau passant par l'interface usb0 et uniquement les trames utilisant le protocol 443
tcpdump_443.pcap

# [tshark] Capture réseau passant par l'interface usb0
tshark.pcap
```

