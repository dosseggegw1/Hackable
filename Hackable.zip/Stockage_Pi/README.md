# Information sur les fichiers de /Stockage_Pi

```shell
# Keylogger linux qui envoi par mail les frappes tous les 50 caractères et 10 minutes
.keylogger-smtp.py			

# Keylogger linux qui doit être stocké dans le stockage de masse de la Pi, il récupère les frappes et les stock aussi dans la Pi.
# /!\ A stocker sur la Pi
.keylogger.py

#  Script Powershell utilisé lors de la configuration d'une machine Windows (désactive le scan Windows Defender pour la Pi, envoi par mail le Path de la Pi et désactive le WiFi).
# /!\ A stocker sur la Pi
config.ps1

# Script Powershell permettant d'exécuter le Keylogger (KeystrokeAPI)
# /!\ A stocker sur la Pi
keylogger.ps1

# Archive qui doit être dézipé et stocké sur la Pi. Elle contient le Keylogger pour Windows
# /!\ A stocker sur la Pi
KeystrokeAPI.zip
```

